import { Routes, Route } from 'react-router';
import Layout from './components/Layout';
import Home from './pages/Home';
import Models from './pages/Models';
import ModelDetail from './pages/ModelDetail';
import Harnesses from './pages/Harnesses';
import Teams from './pages/Teams';
import Scenarios from './pages/Scenarios';
import Guides from './pages/Guides';
import Tools from './pages/Tools';
import Changelog from './pages/Changelog';

/**
 * 嵌套路由模式（Layout 渲染 <Outlet/>，此处使用嵌套 <Route> —— 不可混用 children 模式）。
 */
export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="models" element={<Models />} />
        <Route path="models/claude-opus-4-7" element={<ModelDetail />} />
        <Route path="harnesses" element={<Harnesses />} />
        <Route path="teams" element={<Teams />} />
        <Route path="scenarios" element={<Scenarios />} />
        <Route path="guides" element={<Guides />} />
        <Route path="tools" element={<Tools />} />
        <Route path="changelog" element={<Changelog />} />
      </Route>
    </Routes>
  );
}
