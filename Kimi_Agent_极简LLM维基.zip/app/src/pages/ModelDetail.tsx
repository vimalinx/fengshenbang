import { Link } from 'react-router';
import { motion } from 'framer-motion';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import SectionHeader from '@/components/SectionHeader';
import TierSeal from '@/components/TierSeal';
import StarRating from '@/components/StarRating';
import StatBar from '@/components/StatBar';
import HarnessCard from '@/components/HarnessCard';
import TeamCard from '@/components/TeamCard';
import GuideListItem from '@/components/GuideListItem';
import { Reveal } from '@/components/Reveal';
import { modelMap, systemMap } from '@/data/models';
import { harnessMap } from '@/data/harnesses';
import { teams } from '@/data/teams';
import { guides } from '@/data/guides';
import { cn } from '@/lib/utils';

const model = modelMap['claude-opus-4-7'];
const rival = modelMap['gpt-5-2'];
const sys = systemMap[model.system];
const SYS = sys.color; // 赭珀 #C46A2B

/* ---------- 数据 ---------- */
const statRows: { label: string; value: string }[] = [
  { label: '上下文窗口', value: '1,000,000 tok' },
  { label: '最大输出', value: '128,000 tok' },
  { label: '价格（入/出）', value: '$8 / $40 · Mtok' },
  { label: 'SWE-bench Verified', value: '82.4%' },
  { label: 'LMArena ELO', value: '1412' },
  { label: 'Aider Polyglot', value: '88.1%' },
  { label: '工具调用成功率', value: '96.8%' },
  { label: '自治续航（实测）', value: '≈ 40 h' },
  { label: '发布日期', value: '2026-06-02' },
  { label: '获取方式', value: 'API · Claude Code 内置' },
];

const radarData = [
  { axis: '代码', opus: model.stats.code, rival: rival.stats.code },
  { axis: '推理', opus: model.stats.reasoning, rival: rival.stats.reasoning },
  { axis: '上下文', opus: model.stats.context, rival: rival.stats.context },
  { axis: '速度', opus: model.stats.speed, rival: rival.stats.speed },
  { axis: '多模态', opus: model.stats.multimodal, rival: rival.stats.multimodal },
  { axis: '性价比', opus: model.stats.value, rival: rival.stats.value },
];

const statBars = [
  { label: '代码修行', value: model.stats.code },
  { label: '推理道行', value: model.stats.reasoning },
  { label: '灵力绵长（上下文）', value: model.stats.context },
  { label: '身法速度', value: model.stats.speed },
  { label: '多模态灵觉', value: model.stats.multimodal },
  { label: '机缘（性价比）', value: model.stats.value },
];

const talents = [
  {
    seal: '御',
    name: '长时间自治',
    type: '被动',
    typeColor: '#35618E',
    desc: '无人值守连续作业，任务不跑偏。',
    lv: 'Lv.10：续航 40h，跑偏率 <2%',
  },
  {
    seal: '器',
    name: '工具调用精通',
    type: '主动',
    typeColor: '#C03A28',
    desc: 'MCP 与终端工具如臂使指。',
    lv: 'Lv.10：调用成功率 96.8%，链长上限 200 步',
  },
  {
    seal: '审',
    name: '审慎模式',
    type: '觉醒',
    typeColor: '#B8860B',
    desc: '大额改动前先呈上计划书，获允后方动。',
    lv: 'Lv.10：破坏性操作拦截率 99%',
  },
];

const timeline = [
  { date: '2024-03', name: 'Opus 3', desc: '初登仙班 · 首次超越 GPT-4 世代' },
  { date: '2024-06', name: 'Opus 3.5', desc: '代码修行 +12% · 获封「码仙」' },
  { date: '2025-05', name: 'Opus 4', desc: '自治续航突破 7h · 工具调用觉醒' },
  { date: '2025-11', name: 'Opus 4.5', desc: '上下文扩至 500k · 审慎模式习得' },
  { date: '2026-06', name: 'Opus 4.7', desc: '上下文 1M · 续航 40h · 登临 T0', current: true },
];

const bestInSlot = [
  { id: 'claude-code', note: '本命法宝，同宗同源，自治神通满幅释放。' },
  { id: 'cursor', note: '双模型槽位可组复核流。' },
  { id: 'openhands', note: '蜂群流的御灵底座。' },
];

const teamIds = ['fengshen-flagship', 'puppet-workshop'];

const trialGood = [
  { label: '天柱试炼·长程重构', to: '/scenarios#refactor' },
  { label: '开天试炼·全栈交付', to: '/scenarios#fullstack' },
  { label: '御灵试炼·Agent 开发', to: '/scenarios#agent' },
];
const trialBad = [{ label: '问鼎试炼·算法竞赛', to: '/scenarios#algo', note: '建议换 DeepSeek-R2' }];

const relatedGuides = ['case-refactor', 'xinfu-vol2', 'review-flow', 'mech-toolcall']
  .map((id) => guides.find((g) => g.id === id))
  .filter((g): g is NonNullable<typeof g> => Boolean(g));

/* ---------- 契合度环 ---------- */
function FitRing({ pct, size = 44 }: { pct: number; size?: number }) {
  const r = (size - 6) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }} title={`契合度 ${pct}%`}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="#FFFFFF" stroke="#F5F0E6" strokeWidth={4} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#B8860B"
          strokeWidth={4}
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          whileInView={{ strokeDashoffset: c * (1 - pct / 100) }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: 'easeOut' }}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-mono text-[11px] font-bold text-gold">
        {pct}%
      </span>
    </div>
  );
}

/* ---------- 页面 ---------- */
export default function ModelDetail() {
  return (
    <div>
      {/* S1 PageHero（紧凑版） */}
      <section className="relative overflow-hidden border-b border-line bg-paper-alt py-5">
        <div className="cloud-line pointer-events-none absolute inset-x-0 bottom-0 h-[20px] opacity-50" aria-hidden />
        <div className="relative mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-3 px-4 md:px-6">
          <motion.nav
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="flex items-center gap-1.5 text-xs text-ink-2"
            aria-label="面包屑"
          >
            <Link to="/" className="transition-colors hover:text-cinnabar">
              首页
            </Link>
            <span className="text-ink-3">/</span>
            <Link to="/models" className="transition-colors hover:text-cinnabar">
              角色图鉴
            </Link>
            <span className="text-ink-3">/</span>
            <span className="text-ink-3">Claude Opus 4.7</span>
          </motion.nav>
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="font-mono text-[11px] text-ink-3"
          >
            收录于 2026-06-02 · 本词条更新于 07-18
          </motion.span>
        </div>
      </section>

      <div className="mx-auto max-w-[1280px] px-4 md:px-6">
        {/* S2 角色主面板「仙籍玉册」 */}
        <section className="mt-6 overflow-hidden rounded-xl border border-line bg-white shadow-card lg:grid lg:grid-cols-[2fr_3fr]">
          {/* 左：立绘区 */}
          <div className="relative h-[280px] overflow-hidden bg-gradient-to-br from-gold-soft via-gold-soft/70 to-paper-alt lg:h-auto lg:min-h-[360px]">
            <motion.div
              className="absolute inset-0"
              initial={{ clipPath: 'inset(0 0 0 100%)' }}
              animate={{ clipPath: 'inset(0 0 0 0%)' }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <motion.img
                src="/banner-up-model.png"
                alt="Claude Opus 4.7 立绘"
                className="h-full w-full object-cover object-top"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
                style={{
                  maskImage: 'linear-gradient(to bottom, black 72%, transparent 100%)',
                  WebkitMaskImage: 'linear-gradient(to bottom, black 72%, transparent 100%)',
                }}
              />
            </motion.div>
            {/* 四角云纹金线框 */}
            <div className="pointer-events-none absolute inset-3 border border-gold/40" aria-hidden />
            {(['left-1.5 top-1.5 border-l-2 border-t-2', 'right-1.5 top-1.5 border-r-2 border-t-2', 'bottom-1.5 left-1.5 border-b-2 border-l-2', 'bottom-1.5 right-1.5 border-b-2 border-r-2'] as const).map(
              (pos) => (
                <span key={pos} className={cn('pointer-events-none absolute h-5 w-5 border-gold', pos)} aria-hidden />
              ),
            )}
          </div>

          {/* 右：属性区 */}
          <div className="p-6 md:p-8">
            {/* 标签行 */}
            <div className="flex flex-wrap items-center gap-2">
              <TierSeal tier={model.tier} size={28} />
              <StarRating stars={model.stars} size={12} />
              <motion.span
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-[0.04em] text-white"
                style={{ backgroundColor: SYS }}
              >
                Claude 系 · 赭珀
              </motion.span>
              {['长程自治', '代码', '重构'].map((t, i) => (
                <motion.span
                  key={t}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.26 + i * 0.06 }}
                  className="rounded-full bg-paper px-2.5 py-0.5 text-[11px] tracking-[0.04em] text-ink-2"
                >
                  {t}
                </motion.span>
              ))}
            </div>

            {/* 名称 + 仙号 */}
            <div className="mt-3 flex flex-wrap items-baseline gap-x-4 gap-y-1">
              <h1 className="font-serif text-4xl font-bold leading-tight text-ink">{model.name}</h1>
              <span className="font-brand text-[22px] text-cinnabar">「{model.title}」</span>
            </div>

            {/* 判词 */}
            <div className="mt-4 flex gap-3">
              <motion.span
                className="w-[3px] shrink-0 rounded-full bg-cinnabar"
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                style={{ transformOrigin: 'top' }}
                aria-hidden
              />
              <p className="font-serif text-[15px] italic leading-relaxed text-ink-2">
                「{model.verdict}」
              </p>
            </div>

            {/* 六维属性 */}
            <div className="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-2">
              {statBars.map((s, i) => (
                <StatBar key={s.label} label={s.label} value={s.value} color={SYS} delay={0.4 + i * 0.08} />
              ))}
            </div>

            {/* CTA */}
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/tools"
                className="rounded-lg bg-cinnabar px-5 py-2.5 text-sm font-medium text-white shadow-card transition-all duration-200 hover:scale-[1.02] hover:bg-cinnabar-deep active:scale-[0.98]"
              >
                加入配队模拟 →
              </Link>
              <Link
                to="/guides"
                className="rounded-lg border border-line-strong bg-white px-5 py-2.5 text-sm font-medium text-daiqing transition-all duration-200 hover:border-gold hover:text-cinnabar"
              >
                查看相关攻略
              </Link>
            </div>
          </div>
        </section>

        {/* S3 数值面板 + 六维雷达 */}
        <section className="mt-10 grid gap-6 lg:grid-cols-[7fr_5fr]">
          <Reveal>
            <div className="overflow-hidden rounded-[10px] border border-line bg-white shadow-card">
              <table className="w-full text-sm">
                <tbody>
                  {statRows.map((r, i) => (
                    <motion.tr
                      key={r.label}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.35, delay: i * 0.03 }}
                      className="border-b border-line transition-colors last:border-0 hover:bg-gold-soft/60"
                    >
                      <td className="px-4 py-2.5 text-[13px] text-ink-2">{r.label}</td>
                      <td className="px-4 py-2.5 text-right font-mono text-[13px] font-bold text-gold">
                        {r.value}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="flex h-full flex-col rounded-[10px] border border-line bg-white p-4 shadow-card">
              <div className="mb-1 flex items-center justify-between">
                <span className="font-serif text-sm font-semibold text-ink">六维雷达</span>
                <span className="font-mono text-[11px] text-ink-3">vs GPT-5.2</span>
              </div>
              <motion.div
                className="min-h-[280px] flex-1"
                initial={{ scale: 0, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ type: 'spring', stiffness: 180, damping: 15 }}
                style={{ transformOrigin: 'center' }}
              >
                <ResponsiveContainer width="100%" height={290}>
                  <RadarChart data={radarData} outerRadius="72%">
                    <PolarGrid stroke="#E7DFCC" />
                    <PolarAngleAxis dataKey="axis" tick={{ fill: '#6E6455', fontSize: 12 }} />
                    <Radar
                      name="Claude Opus 4.7"
                      dataKey="opus"
                      stroke={SYS}
                      strokeWidth={2}
                      fill={SYS}
                      fillOpacity={0.3}
                      dot={{ r: 3, fill: SYS, strokeWidth: 0 }}
                    />
                    <Radar
                      name="GPT-5.2"
                      dataKey="rival"
                      stroke="#2E8B8B"
                      strokeWidth={1.5}
                      strokeDasharray="5 4"
                      fill="#2E8B8B"
                      fillOpacity={0.06}
                      dot={{ r: 2.5, fill: '#2E8B8B', strokeWidth: 0 }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </motion.div>
              <p className="mt-1 text-center font-mono text-[11px] text-ink-3">
                虚线为同位阶对照 · 数据为演示 mock
              </p>
            </div>
          </Reveal>
        </section>

        {/* S4 天赋 · 神通 */}
        <section className="mt-12">
          <SectionHeader title="天赋 · 神通" en="// TALENTS" />
          <div className="grid gap-4 md:grid-cols-3">
            {talents.map((t, i) => (
              <Reveal key={t.name} delay={i * 0.12} className="h-full">
                <div className="group h-full rounded-[10px] border border-line bg-white p-4 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-gold hover:shadow-card-hover">
                  <div className="flex items-center justify-between">
                    <span className="flex h-7 w-7 items-center justify-center rounded-md bg-cinnabar font-serif text-[13px] font-bold text-white shadow-sm">
                      {t.seal}
                    </span>
                    <span
                      className="rounded-full px-2 py-0.5 text-[11px] font-medium tracking-[0.04em] text-white"
                      style={{ backgroundColor: t.typeColor }}
                    >
                      {t.type}
                    </span>
                  </div>
                  <h3 className="mt-3 font-serif text-base font-semibold text-ink transition-colors group-hover:text-cinnabar">
                    {t.name}
                  </h3>
                  <p className="mt-1.5 text-[13px] leading-[1.7] text-ink-2">{t.desc}</p>
                  <p className="mt-3 border-t border-line pt-2.5 font-mono text-xs font-bold text-gold">
                    {t.lv}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* S5 命座 · 版本迭代史 */}
        <section className="mt-12">
          <SectionHeader title="命座 · 迭代" en="// CONSTELLATION" />
          <p className="-mt-3 mb-5 text-xs text-ink-3">命座 = 版本迭代带来的天赋强化</p>
          <div className="overflow-x-auto pb-2">
            <div className="relative min-w-[1180px] px-2">
              {/* 金色主线 */}
              <motion.div
                className="absolute left-0 right-0 top-1/2 h-[2px] -translate-y-1/2 bg-gold/50"
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1, ease: 'easeInOut' }}
                style={{ transformOrigin: 'left' }}
                aria-hidden
              />
              <div className="relative flex justify-between">
                {timeline.map((n, i) => {
                  const card = (
                    <div
                      className={cn(
                        'relative h-[108px] w-[200px] rounded-[10px] border bg-white p-3 shadow-card',
                        n.current ? 'border-cinnabar/50' : 'border-line',
                      )}
                    >
                      {n.current && (
                        <span className="absolute -right-1.5 -top-1.5 rotate-6 rounded-[4px] bg-cinnabar px-1.5 py-px font-serif text-[10px] font-bold text-white shadow-sm">
                          当期
                        </span>
                      )}
                      <div className={cn('font-mono text-[11px]', n.current ? 'text-cinnabar' : 'text-gold')}>
                        {n.date}
                      </div>
                      <div className="mt-0.5 font-serif text-sm font-bold text-ink">{n.name}</div>
                      <div className="mt-1 text-xs leading-[1.6] text-ink-2">{n.desc}</div>
                    </div>
                  );
                  const above = i % 2 === 0;
                  return (
                    <motion.div
                      key={n.name}
                      className="flex h-[248px] w-[200px] shrink-0 flex-col items-center"
                      initial={{ opacity: 0, scale: 0.6 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ type: 'spring', stiffness: 300, damping: 18, delay: i * 0.1 }}
                    >
                      <div className="flex h-[108px] items-end">{above ? card : null}</div>
                      {/* 节点圆点 */}
                      <div className="relative flex h-8 items-center justify-center">
                        {n.current && (
                          <motion.span
                            className="absolute h-5 w-5 rounded-full border-2 border-gold"
                            animate={{ opacity: [0.5, 0], scale: [1, 2] }}
                            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeOut' }}
                            aria-hidden
                          />
                        )}
                        <span
                          className={cn(
                            'relative h-3 w-3 rounded-full border-2 border-white shadow',
                            n.current ? 'bg-cinnabar' : 'bg-gold',
                          )}
                        />
                      </div>
                      <div className="flex h-[108px] items-start">{above ? null : card}</div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* S6 推荐法宝「配装」 */}
        <section className="mt-12">
          <SectionHeader title="推荐法宝" en="// BEST IN SLOT" moreTo="/harnesses" moreLabel="全部法宝 →" />
          <div className="grid gap-4 md:grid-cols-3">
            {bestInSlot.map((b, i) => {
              const h = harnessMap[b.id];
              const fit = h.topFits.find((f) => f.modelId === model.id)?.pct ?? 0;
              return (
                <Reveal key={b.id} delay={i * 0.1}>
                  <div className="relative pt-3">
                    <div className="absolute right-3 top-0 z-10">
                      <FitRing pct={fit} />
                    </div>
                    <HarnessCard harness={h} />
                    <p className="mt-2 px-1 font-serif text-xs italic text-ink-2">「{b.note}」</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </section>

        {/* S7 推荐配队 */}
        <section className="mt-12">
          <SectionHeader title="推荐配队" en="// TEAMS" moreTo="/teams" moreLabel="配队推演 →" />
          <div className="space-y-4">
            {teamIds.map((id, i) => {
              const team = teams.find((t) => t.id === id);
              if (!team) return null;
              return (
                <Reveal key={id} delay={i * 0.1}>
                  <TeamCard team={team} />
                </Reveal>
              );
            })}
          </div>
        </section>

        {/* S8 适用试炼 */}
        <section className="mt-12">
          <SectionHeader title="试炼相性" en="// AFFINITY" />
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-14 shrink-0 font-serif text-xs font-semibold text-cinnabar">擅长</span>
              {trialGood.map((t, i) => (
                <motion.span
                  key={t.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ type: 'spring', stiffness: 360, damping: 16, delay: i * 0.05 }}
                >
                  <Link
                    to={t.to}
                    className="inline-block rounded-full bg-cinnabar/10 px-3 py-1.5 text-xs font-medium text-cinnabar transition-colors duration-200 hover:bg-cinnabar hover:text-white"
                  >
                    {t.label}
                  </Link>
                </motion.span>
              ))}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-14 shrink-0 font-serif text-xs font-semibold text-ink-3">不擅长</span>
              {trialBad.map((t, i) => (
                <motion.span
                  key={t.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ type: 'spring', stiffness: 360, damping: 16, delay: 0.15 + i * 0.05 }}
                  className="flex items-center gap-2"
                >
                  <Link
                    to={t.to}
                    className="inline-block rounded-full bg-paper px-3 py-1.5 text-xs font-medium text-ink-2 transition-colors duration-200 hover:bg-ink-3 hover:text-white"
                  >
                    {t.label}
                  </Link>
                  <span className="font-mono text-[11px] text-ink-3">（{t.note}）</span>
                </motion.span>
              ))}
            </div>
          </div>
        </section>

        {/* S9 相关攻略 */}
        <section className="my-12">
          <SectionHeader title="相关攻略" en="// GUIDES" moreTo="/guides" moreLabel="攻略阁 →" />
          <Reveal>
            <div className="divide-y divide-line rounded-[10px] border border-line bg-white px-2 py-1 shadow-card">
              {relatedGuides.map((g) => (
                <GuideListItem key={g.id} guide={g} />
              ))}
            </div>
          </Reveal>
        </section>
      </div>
    </div>
  );
}
